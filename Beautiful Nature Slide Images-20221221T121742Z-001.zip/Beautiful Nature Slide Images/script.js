const PrevBtn= document.querySelector('.PrevBtn');
const NextBtn= document.querySelector('.NextBtn');

const container=document.querySelector('.images');

let counter= 0;

NextBtn.addEventListener('click',next);
PrevBtn.addEventListener('click',previous);




function next(){

    container.animate([{opacity:'0.1'},{opacity:'1.0'}],{duration:1000,fill:'forwards'});

    if (counter===16){

        counter=-1;
    }

counter++;
container.style.backgroundImage=`url(imgs/img-${counter}.jpg`

}



function previous(){
    container.animate([{opacity:'0.1'},{opacity:'1.0'}],{duration:1000,fill:'forwards'});

    if (counter===0){

        counter=16;
    }

counter--;
container.style.backgroundImage=`url(imgs/img-${counter}.jpg`

}
